// Export pages
export '/home_page/home_page_widget.dart' show HomePageWidget;
export '/analyst/analyst_widget.dart' show AnalystWidget;
export '/infomation/infomation_widget.dart' show InfomationWidget;
export '/setting/setting_widget.dart' show SettingWidget;
export '/news/news_widget.dart' show NewsWidget;
