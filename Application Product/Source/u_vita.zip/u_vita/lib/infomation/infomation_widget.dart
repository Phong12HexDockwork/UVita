import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/widget/battery/battery_widget.dart';
import '/widget/daily_trackers/daily_trackers_widget.dart';
import '/widget/team/team_widget.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'infomation_model.dart';
export 'infomation_model.dart';

class InfomationWidget extends StatefulWidget {
  const InfomationWidget({super.key});

  @override
  State<InfomationWidget> createState() => _InfomationWidgetState();
}

class _InfomationWidgetState extends State<InfomationWidget> {
  late InfomationModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InfomationModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                wrapWithModel(
                  model: _model.dailyTrackersModel,
                  updateCallback: () => safeSetState(() {}),
                  child: DailyTrackersWidget(),
                ),
                Align(
                  alignment: AlignmentDirectional(0.0, -1.0),
                  child: wrapWithModel(
                    model: _model.batteryModel,
                    updateCallback: () => safeSetState(() {}),
                    child: BatteryWidget(),
                  ),
                ),
                wrapWithModel(
                  model: _model.teamModel,
                  updateCallback: () => safeSetState(() {}),
                  child: TeamWidget(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
