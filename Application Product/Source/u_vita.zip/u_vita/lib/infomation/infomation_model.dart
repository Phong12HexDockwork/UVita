import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/widget/battery/battery_widget.dart';
import '/widget/daily_trackers/daily_trackers_widget.dart';
import '/widget/team/team_widget.dart';
import 'infomation_widget.dart' show InfomationWidget;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InfomationModel extends FlutterFlowModel<InfomationWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for DailyTrackers component.
  late DailyTrackersModel dailyTrackersModel;
  // Model for Battery component.
  late BatteryModel batteryModel;
  // Model for team component.
  late TeamModel teamModel;

  @override
  void initState(BuildContext context) {
    dailyTrackersModel = createModel(context, () => DailyTrackersModel());
    batteryModel = createModel(context, () => BatteryModel());
    teamModel = createModel(context, () => TeamModel());
  }

  @override
  void dispose() {
    dailyTrackersModel.dispose();
    batteryModel.dispose();
    teamModel.dispose();
  }
}
