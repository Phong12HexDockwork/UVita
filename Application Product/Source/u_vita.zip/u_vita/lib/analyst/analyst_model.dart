import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/widget/advice/advice_widget.dart';
import '/widget/advice_copy/advice_copy_widget.dart';
import '/widget/box/box_widget.dart';
import '/widget/dashboard01_recent_activity/dashboard01_recent_activity_widget.dart';
import '/widget/healthy/healthy_widget.dart';
import '/widget/healthy_copy/healthy_copy_widget.dart';
import '/widget/material_card2/material_card2_widget.dart';
import '/widget/temp_and_u_v/temp_and_u_v_widget.dart';
import '/widget/time_count/time_count_widget.dart';
import 'analyst_widget.dart' show AnalystWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AnalystModel extends FlutterFlowModel<AnalystWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Time_Count component.
  late TimeCountModel timeCountModel;
  // Model for box component.
  late BoxModel boxModel;
  // Model for TempAndUV component.
  late TempAndUVModel tempAndUVModel;
  // Model for Dashboard01RecentActivity component.
  late Dashboard01RecentActivityModel dashboard01RecentActivityModel;
  // Model for MaterialCard2 component.
  late MaterialCard2Model materialCard2Model;
  // Model for Advice component.
  late AdviceModel adviceModel;
  // Model for AdviceCopy component.
  late AdviceCopyModel adviceCopyModel;
  // Model for HealthyCopy component.
  late HealthyCopyModel healthyCopyModel;
  // Model for Healthy component.
  late HealthyModel healthyModel;

  @override
  void initState(BuildContext context) {
    timeCountModel = createModel(context, () => TimeCountModel());
    boxModel = createModel(context, () => BoxModel());
    tempAndUVModel = createModel(context, () => TempAndUVModel());
    dashboard01RecentActivityModel =
        createModel(context, () => Dashboard01RecentActivityModel());
    materialCard2Model = createModel(context, () => MaterialCard2Model());
    adviceModel = createModel(context, () => AdviceModel());
    adviceCopyModel = createModel(context, () => AdviceCopyModel());
    healthyCopyModel = createModel(context, () => HealthyCopyModel());
    healthyModel = createModel(context, () => HealthyModel());
  }

  @override
  void dispose() {
    timeCountModel.dispose();
    boxModel.dispose();
    tempAndUVModel.dispose();
    dashboard01RecentActivityModel.dispose();
    materialCard2Model.dispose();
    adviceModel.dispose();
    adviceCopyModel.dispose();
    healthyCopyModel.dispose();
    healthyModel.dispose();
  }
}
