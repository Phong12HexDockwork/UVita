import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/widget/advice/advice_widget.dart';
import '/widget/advice_copy/advice_copy_widget.dart';
import '/widget/box/box_widget.dart';
import '/widget/dashboard01_recent_activity/dashboard01_recent_activity_widget.dart';
import '/widget/healthy/healthy_widget.dart';
import '/widget/healthy_copy/healthy_copy_widget.dart';
import '/widget/material_card2/material_card2_widget.dart';
import '/widget/temp_and_u_v/temp_and_u_v_widget.dart';
import '/widget/time_count/time_count_widget.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'analyst_model.dart';
export 'analyst_model.dart';

class AnalystWidget extends StatefulWidget {
  const AnalystWidget({super.key});

  @override
  State<AnalystWidget> createState() => _AnalystWidgetState();
}

class _AnalystWidgetState extends State<AnalystWidget> {
  late AnalystModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AnalystModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Color(0xFFDDDCDC),
        body: SafeArea(
          top: true,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Padding(
                  padding: EdgeInsets.all(22.0),
                  child: wrapWithModel(
                    model: _model.timeCountModel,
                    updateCallback: () => safeSetState(() {}),
                    child: TimeCountWidget(),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(2.0),
                  child: wrapWithModel(
                    model: _model.boxModel,
                    updateCallback: () => safeSetState(() {}),
                    child: BoxWidget(),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(6.0),
                  child: wrapWithModel(
                    model: _model.tempAndUVModel,
                    updateCallback: () => safeSetState(() {}),
                    child: TempAndUVWidget(),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(4.0),
                  child: wrapWithModel(
                    model: _model.dashboard01RecentActivityModel,
                    updateCallback: () => safeSetState(() {}),
                    child: Dashboard01RecentActivityWidget(),
                  ),
                ),
                wrapWithModel(
                  model: _model.materialCard2Model,
                  updateCallback: () => safeSetState(() {}),
                  child: MaterialCard2Widget(),
                ),
                Padding(
                  padding: EdgeInsets.all(20.0),
                  child: wrapWithModel(
                    model: _model.adviceModel,
                    updateCallback: () => safeSetState(() {}),
                    child: AdviceWidget(),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(20.0),
                  child: wrapWithModel(
                    model: _model.adviceCopyModel,
                    updateCallback: () => safeSetState(() {}),
                    child: AdviceCopyWidget(),
                  ),
                ),
                wrapWithModel(
                  model: _model.healthyCopyModel,
                  updateCallback: () => safeSetState(() {}),
                  child: HealthyCopyWidget(),
                ),
                wrapWithModel(
                  model: _model.healthyModel,
                  updateCallback: () => safeSetState(() {}),
                  child: HealthyWidget(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
