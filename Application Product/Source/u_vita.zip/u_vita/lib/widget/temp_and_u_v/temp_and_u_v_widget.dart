import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'temp_and_u_v_model.dart';
export 'temp_and_u_v_model.dart';

class TempAndUVWidget extends StatefulWidget {
  const TempAndUVWidget({super.key});

  @override
  State<TempAndUVWidget> createState() => _TempAndUVWidgetState();
}

class _TempAndUVWidgetState extends State<TempAndUVWidget> {
  late TempAndUVModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TempAndUVModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: 0.8,
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(16.0, 16.0, 16.0, 16.0),
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            color: Color(0xFF710F0F),
            borderRadius: BorderRadius.circular(16.0),
          ),
          child: Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'UV Index',
                          style: FlutterFlowTheme.of(context)
                              .headlineSmall
                              .override(
                                fontFamily: 'Inter Tight',
                                color: Colors.white,
                                letterSpacing: 0.0,
                              ),
                        ),
                        Text(
                          'Moderate',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    color: Color(0xFF96989C),
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ],
                    ),
                    Text(
                      '5.6',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Inter',
                            color: Color(0xFFFDFAF9),
                            fontSize: 29.0,
                            letterSpacing: 0.0,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                  ],
                ),
                Container(
                  width: double.infinity,
                  child: Slider(
                    activeColor: Color(0xFF00FFFD),
                    inactiveColor: Color(0xFFE0E0E0),
                    min: 0.0,
                    max: 11.0,
                    value: _model.sliderValue1 ??= 5.0,
                    onChanged: (newValue) {
                      newValue = double.parse(newValue.toStringAsFixed(4));
                      safeSetState(() => _model.sliderValue1 = newValue);
                    },
                  ),
                ),
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Temperature',
                          style: FlutterFlowTheme.of(context)
                              .headlineSmall
                              .override(
                                fontFamily: 'Inter Tight',
                                color: Colors.white,
                                letterSpacing: 0.0,
                              ),
                        ),
                        Text(
                          'Warm',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    color: Color(0xFF9EA1A3),
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ],
                    ),
                    Text(
                      '28°C',
                      style:
                          FlutterFlowTheme.of(context).headlineMedium.override(
                                fontFamily: 'Inter Tight',
                                color: Colors.white,
                                letterSpacing: 0.0,
                              ),
                    ),
                  ],
                ),
                Container(
                  width: double.infinity,
                  child: Slider(
                    activeColor: Color(0xFFFFC122),
                    inactiveColor: Color(0xFFE0E0E0),
                    min: -10.0,
                    max: 40.0,
                    value: _model.sliderValue2 ??= 28.0,
                    onChanged: (newValue) {
                      newValue = double.parse(newValue.toStringAsFixed(4));
                      safeSetState(() => _model.sliderValue2 = newValue);
                    },
                  ),
                ),
                Text(
                  '28°C',
                  style: FlutterFlowTheme.of(context).headlineMedium.override(
                        fontFamily: 'Inter Tight',
                        color: Colors.white,
                        letterSpacing: 0.0,
                      ),
                ),
              ].divide(SizedBox(height: 16.0)),
            ),
          ),
        ),
      ),
    );
  }
}
