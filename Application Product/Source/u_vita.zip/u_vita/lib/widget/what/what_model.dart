import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'what_widget.dart' show WhatWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class WhatModel extends FlutterFlowModel<WhatWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
