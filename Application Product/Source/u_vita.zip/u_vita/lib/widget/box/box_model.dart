import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'box_widget.dart' show BoxWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class BoxModel extends FlutterFlowModel<BoxWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
