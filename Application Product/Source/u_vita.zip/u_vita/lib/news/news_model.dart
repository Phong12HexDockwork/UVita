import '/components/card35_news_article_widget.dart';
import '/components/card38_location_details_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'news_widget.dart' show NewsWidget;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NewsModel extends FlutterFlowModel<NewsWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Card38LocationDetails component.
  late Card38LocationDetailsModel card38LocationDetailsModel;
  // Model for Card35NewsArticle component.
  late Card35NewsArticleModel card35NewsArticleModel;

  @override
  void initState(BuildContext context) {
    card38LocationDetailsModel =
        createModel(context, () => Card38LocationDetailsModel());
    card35NewsArticleModel =
        createModel(context, () => Card35NewsArticleModel());
  }

  @override
  void dispose() {
    card38LocationDetailsModel.dispose();
    card35NewsArticleModel.dispose();
  }
}
