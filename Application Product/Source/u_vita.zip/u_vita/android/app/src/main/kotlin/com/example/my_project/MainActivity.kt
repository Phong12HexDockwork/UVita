package com.mycompany.uvita

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
